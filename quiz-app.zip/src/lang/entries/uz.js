import uzMsg from "../locales/uz.json";

const UzLang = {
  locale: 'uz',
  messages: {
    ...uzMsg
  },
};
export default UzLang;
