import { all } from "redux-saga/effects";
import auth from "./auth";
import subject from "./subject";

export default function* rootSaga(getState) {
  yield all([auth(), subject()]);
}
