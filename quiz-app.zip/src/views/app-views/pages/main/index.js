import { Layout } from "antd";
import { Header } from "antd/lib/layout/layout";

const MainPage = () => {
  return (
    <Layout>
      <Header />
      222
    </Layout>
  );
};

export default MainPage;
