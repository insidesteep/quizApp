import { Result, Typography, Row, Col, Card } from "antd";
import { useSelector } from "react-redux";
import Flex from "../../../../components/Flex";

const { Paragraph, Text } = Typography;

const SuccessfuRegistration = () => {
  const { termRegData } = useSelector((state) => state.auth);

  return (
    <div className="auth-wrapper">
      <Flex alignItems="center" justifyContent="center">
        <Row align="center">
          <Col sm={12} xs={22}>
            <Card>
              {" "}
              <Result
                status="success"
                title="Вы успешно зарегистрированы"
                subTitle={
                  <Paragraph type="secondary">
                    Вы стали участником Международной студенческой онлайн
                    олимпиады студентов медицинских вузов «От учения Абу Али ибн
                    Сино - до Третьего ренессанса», которая пройдет{" "}
                    <Text type="success">21 января 2022 года</Text>."
                  </Paragraph>
                }
                extra={[
                  <>
                    {termRegData && (
                      <>
                        <Paragraph>
                          Ваш логин:{" "}
                          <Text type="danger">{termRegData.email}</Text>
                        </Paragraph>
                        <Paragraph>
                          Ваш пароль:{" "}
                          <Text type="danger">
                            {termRegData.password.slice(0, 3) + "*****"}
                          </Text>
                        </Paragraph>
                      </>
                    )}
                  </>,
                ]}
              />
            </Card>
          </Col>
        </Row>
      </Flex>
    </div>
  );
};

export default SuccessfuRegistration;
